using Microsoft.AspNetCore.Identity;

namespace TodoList.Persistence
{
    public class ApplicationUser : IdentityUser
    {
    }
}