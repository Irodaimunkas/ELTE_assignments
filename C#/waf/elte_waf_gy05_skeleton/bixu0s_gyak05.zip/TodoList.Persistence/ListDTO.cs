﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TodoList.Persistence
{
    class ListDTO
    {
        public Int32 Id { get; set; }

        public String Name { get; set; }
    }
}
